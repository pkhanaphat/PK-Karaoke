﻿#include "Core/MidiPlayer.h"

MidiPlayer::MidiPlayer() {}

bool MidiPlayer::loadMidiFile(const juce::File &file) {
  const juce::ScopedLock sl(lock);

  juce::FileInputStream stream(file);
  if (stream.openedOk()) {
    juce::MidiFile midiFile;
    if (midiFile.readFrom(stream)) {
      midiResolution = midiFile.getTimeFormat();

      // 1. First, create the TICK-based sequence BEFORE doing any conversion
      juce::MidiMessageSequence mergedTicksSequence;
      for (int i = 0; i < midiFile.getNumTracks(); ++i) {
        if (auto *track = midiFile.getTrack(i))
          mergedTicksSequence.addSequence(*track, 0.0);
      }
      mergedTicksSequence.updateMatchedPairs();
      midiSequenceTicks.clear();
      midiSequenceTicks.addSequence(mergedTicksSequence, 0.0);
      durationTicks = midiSequenceTicks.getEndTime();

      // 2. NOW convert the original file to seconds
      midiFile.convertTimestampTicksToSeconds();

      // 3. Create the SECONDS-based sequence
      juce::MidiMessageSequence mergedSequence;
      for (int i = 0; i < midiFile.getNumTracks(); ++i) {
        if (auto *track = midiFile.getTrack(i))
          mergedSequence.addSequence(*track, 0.0);
      }
      mergedSequence.updateMatchedPairs();

      // Re-store the sorted, merged sequence back into our player sequence
      midiSequence.clear();
      midiSequence.addSequence(mergedSequence, 0.0);

      durationSeconds = midiSequence.getEndTime();
      DBG("MidiPlayer: Loaded file. Tracks="
          << midiFile.getNumTracks()
          << ", Events=" << midiSequence.getNumEvents()
          << ", Duration=" << durationSeconds << "s");

      if (durationSeconds <= 0.0) {
        DBG("MidiPlayer: Warning - Duration is zero or negative! Forcing "
            "fallback duration.");
        durationSeconds = 60.0; // Fallback so it doesn't instantly stop
      }

      currentPositionSeconds = 0.0;
      nextEventIndex = 0;
      playing = false;
      reachedEnd = false;

      return true;
    }
  }
  DBG("MidiPlayer: Error loading MIDI file from stream.");
  return false;
}

void MidiPlayer::setPosition(double timeInSeconds) {
  const juce::ScopedLock sl(lock);
  currentPositionSeconds = juce::jlimit(0.0, durationSeconds, timeInSeconds);

  // Find the next event index based on the new time
  nextEventIndex = midiSequence.getNextIndexAtTime(currentPositionSeconds);
  reachedEnd = false;
}

double MidiPlayer::getPosition() const { return currentPositionSeconds; }

int MidiPlayer::getPositionTicks() const {
  if (midiSequenceTicks.getNumEvents() == 0 || currentPositionSeconds <= 0.0)
    return 0;

  double accumulatedTime = 0.0;
  int currentTick = 0;

  // JUCE's default behavior if no tempo is specified
  double secondsPerQuarterNote = 0.5; // 120 BPM

  for (int i = 0; i < midiSequenceTicks.getNumEvents(); ++i) {
    auto *event = midiSequenceTicks.getEventPointer(i);
    int eventTick = event->message.getTimeStamp();

    // Calculate time passed since last event using the current tempo
    double ticksDelta = eventTick - currentTick;
    double timeDelta = (ticksDelta / midiResolution) * secondsPerQuarterNote;

    // If adding this delta exceeds our target time, we interpolate the tick
    if (accumulatedTime + timeDelta > currentPositionSeconds) {
      double remainingTime = currentPositionSeconds - accumulatedTime;
      double remainingTicks =
          (remainingTime / secondsPerQuarterNote) * midiResolution;
      return currentTick + static_cast<int>(remainingTicks);
    }

    currentTick = eventTick;
    accumulatedTime += timeDelta;

    // Update tempo if this event is a tempo change
    if (event->message.isTempoMetaEvent()) {
      secondsPerQuarterNote = event->message.getTempoSecondsPerQuarterNote();
    }
  }

  return durationTicks;
}

double MidiPlayer::getDuration() const { return durationSeconds; }

void MidiPlayer::play() {
  playing = true;
  reachedEnd = false;
}

void MidiPlayer::pause() { playing = false; }

void MidiPlayer::stop() {
  const juce::ScopedLock sl(lock);
  playing = false;
  reachedEnd = false;
  currentPositionSeconds = 0.0;
  nextEventIndex = 0;
}

bool MidiPlayer::isPlaying() const { return playing; }

void MidiPlayer::getNextAudioBlock(juce::MidiBuffer &outputBuffer,
                                   int numSamples, double sampleRate) {
  outputBuffer.clear();

  if (!playing || midiSequence.getNumEvents() == 0)
    return;

  const juce::ScopedLock sl(lock);

  // Calculate how much time this buffer represents
  double bufferDurationSeconds = numSamples / sampleRate;
  double endPositionSeconds = currentPositionSeconds + bufferDurationSeconds;

  // Extract events within this time window
  while (nextEventIndex < midiSequence.getNumEvents()) {
    auto *event = midiSequence.getEventPointer(nextEventIndex);
    double eventTime = event->message.getTimeStamp();

    if (eventTime >= endPositionSeconds)
      break; // Event is beyond the current buffer

    // Convert event time to sample position within the buffer
    int sampleOffset = (int)((eventTime - currentPositionSeconds) * sampleRate);
    sampleOffset = juce::jlimit(0, numSamples - 1, sampleOffset);

    outputBuffer.addEvent(event->message, sampleOffset);
    // DBG("MidiPlayer: Event at " << eventTime << "s (offset " << sampleOffset
    // << ")");
    nextEventIndex++;
  }

  if (outputBuffer.getNumEvents() > 0)
    DBG("MidiPlayer: Pushed " << outputBuffer.getNumEvents()
                              << " events to buffer");

  currentPositionSeconds = endPositionSeconds;

  if (currentPositionSeconds >= durationSeconds) {
    DBG("MidiPlayer: Reached end of duration (" << durationSeconds
                                                << "s). Stopping playback.");
    playing = false; // Finished playback
    reachedEnd = true;
  }
}
